import java.util.ArrayList;
import java.util.HashMap;

public class GestioneRubriche {

	private static HashMap<String, Rubrica> listaRubriche =new HashMap<String, Rubrica>();
	
	public static int crea(String nome, int dimensione){
		if (listaRubriche.containsKey(nome)) return -1;
		listaRubriche.put(nome,new Rubrica(nome,dimensione));
		return 1;
	}
	
	public static int delete(String nome){
		if (listaRubriche.containsKey(nome)){ 
			listaRubriche.remove(nome);
			return 1;
		}
		return -1;
	}
	
	public static int add(String nome, String contatto){
		if (listaRubriche.containsKey(nome)){
			return listaRubriche.get(nome).aggiungi(contatto);
			
		}
		return -2;
	}
    
	public static ArrayList<String> cerca(String nomeRubrica,String prefix){
		if(listaRubriche.containsKey(nomeRubrica)) {		
			return listaRubriche.get(nomeRubrica).cerca(prefix);
		}
		return null;
	}
	
	
	public static boolean elimina(String nomeRubrica, String prefix){
		if(listaRubriche.containsKey(nomeRubrica)) {
			return listaRubriche.get(nomeRubrica).elimina(prefix);
		}
		return false;
	}
	
	public static String RutoStr(String nomeRubrica) {
		String g= "";
		if(listaRubriche.containsKey(nomeRubrica)) {
			g = listaRubriche.get(nomeRubrica).toString();
			return g;
		}
		return g;
	}
	
	public static int numRu(String nomeRubr) {
		if(listaRubriche.containsKey(nomeRubr)) {
			return listaRubriche.get(nomeRubr).numEl();
		}
		return -2;
	}

	
	public static void reset() {

        listaRubriche =new HashMap<String, Rubrica>();

    }
	
	
	
	
}
