import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class GestioneRubricheTest {

	
	@Before
	  public void inizializza() {

        GestioneRubriche.reset();
     }
	
	@Test
	public void test() {
		assertEquals(GestioneRubriche.crea("Amici",5),1);
		assertEquals(GestioneRubriche.crea("Nemici",5),1);
		assertEquals(GestioneRubriche.crea("Dolci",5),1);
	}

}
