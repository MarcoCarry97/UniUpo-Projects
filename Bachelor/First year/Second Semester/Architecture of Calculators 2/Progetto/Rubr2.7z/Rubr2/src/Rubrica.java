import java.util.ArrayList;

public class Rubrica {
	
	
	private ArrayList<String> rubrica;
	public final int DIM_MAX;
	public final String NOME;
	
	Rubrica(String nome, int massimo)
	{
		rubrica = new ArrayList<String>(); 
		NOME=nome;  
		DIM_MAX=massimo;
	}
	
	Rubrica(String nome)
	{
		this(nome, 10);
	}
	
	Rubrica()
	{
		this("Rubrica");
	}
	
	public int numEl() {
		return rubrica.size();
	}

	public  int aggiungi(String s) {
		if (rubrica.size()>=DIM_MAX) return -1;
		if (rubrica.contains(s)) return 0;
		rubrica.add(s);
		return 1;
	}
	
	public boolean elimina(String s)
	{
		return rubrica.removeAll(cerca(s));
	}
	
	public ArrayList<String> cerca(String s)
	{
		ArrayList<String> temp = new ArrayList<String>();
		for(String contatto:rubrica) {
            if(contatto.startsWith(s))  temp.add(contatto);
		}   
		return temp;
	}
	
	public String toString()
	{
		return rubrica.toString();
	}
}
