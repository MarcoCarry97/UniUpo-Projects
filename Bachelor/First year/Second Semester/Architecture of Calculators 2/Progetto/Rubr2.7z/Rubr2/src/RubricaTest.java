import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RubricaTest{
    Rubrica r1;
    Rubrica r2;
    
	@Before
	public void inizializzazione() {
        r1 = new Rubrica("GoT", 5);
        r2 = new Rubrica();
 	}
	
	@Test
	public void testCreazione() {
 		assertTrue(r1.numEl()==0);
 		assertEquals(r1.NOME,"GoT");
        assertEquals(r1.DIM_MAX,5 );
		assertTrue(r2.numEl()==0 );
		assertEquals(r2.NOME,"Rubrica");
 		assertEquals(r2.DIM_MAX,10);
	}
	
	
	
	@Test
	public void TestAggiuntaSame() {
		// Test aggiunta di una stringa gi� presesnte (r1)
		r1.aggiungi("Arya=1234567");
		assertTrue(r1.numEl()==1);
		assertEquals(r1.aggiungi("Arya=1234567"), 0);
		assertTrue(r1.numEl()==1);
		
		// Test aggiunta di una stringa gi� presesnte (r2)
		r2.aggiungi("Sansa=1222567");
		assertTrue(r2.numEl()==1);
		assertEquals(r2.aggiungi("Sansa=1222567"), 0);
		assertTrue(r2.numEl()==1);
	}
	@Test
	public void TestAggiuntaFull() {
		// Test riempimento r1
		r1.aggiungi("Arya=1234567");
		assertTrue(r1.numEl()==1);
		r1.aggiungi("Sansa=7654321");
		assertTrue(r1.numEl()==2);
		r1.aggiungi("Jon=7756756756");
		assertTrue(r1.numEl()==3);
		r1.aggiungi("Jamie=1111111");
		assertTrue(r1.numEl()==4);
		assertEquals(r1.aggiungi("Cersei=000666000"), 1);
		assertTrue(r1.numEl()==5);
	}


	@Test
	public void TestAggiuntaOver()
	{
		// Test aggiunta oltre il limite per r1
		r1.aggiungi("Arya=1234567");
		r1.aggiungi("Sansa=7654321");
		r1.aggiungi("Jon=7756756756");
		r1.aggiungi("Jamie=1111111");
		r1.aggiungi("Cersei=000666000");
		assertEquals(r1.aggiungi("Olenna=999999"), -1);
		assertTrue(r1.numEl()==5);		
	}
	
	@Test
	public void TestRicerca() {
		// Aggiunta di elementi a r1
		r1.aggiungi("Arya=1234567");
		r1.aggiungi("Sansa=7654321");
		r1.aggiungi("Jon=7756756756");
		r1.aggiungi("Jamie=1111111");
		r1.aggiungi("Cersei=000666000");
		
		// Test Ricerca elementi in r1
		assertEquals(r1.cerca("J").size(),2);
		assertEquals(r1.cerca("").size(),5);
		assertEquals(r1.cerca("M").size(),0);

	}


	@Test
	public void testEliminaNessuno(){
		// Aggiunta di elementi a r1
		r1.aggiungi("Arya=1234567");
		r1.aggiungi("Sansa=7654321");
		r1.aggiungi("Jon=7756756756");
		r1.aggiungi("Jamie=1111111");
		r1.aggiungi("Cersei=000666000");
		
		assertTrue(r1.numEl()==5);
		assertFalse(r1.elimina("Al"));
		assertTrue(r1.numEl()==5);
		assertFalse(r1.elimina("=12"));
		assertTrue(r1.numEl()==5);
	}
	
	
	@Test
	public void testEliminaPrimoUltimo(){
		// Aggiunta di elementi a r1
		r1.aggiungi("Arya=1234567");
		r1.aggiungi("Sansa=7654321");
		r1.aggiungi("Jon=7756756756");
		r1.aggiungi("Jamie=1111111");
		r1.aggiungi("Cersei=000666000");
		
		assertTrue(r1.numEl()==5);
		assertFalse(r1.elimina("Aria"));
		assertTrue(r1.elimina("Arya"));
		assertTrue(r1.numEl()==4);
		assertTrue(r1.elimina("Cersei"));
		assertTrue(r1.numEl()==3);
	}


    @Test
	public void testEliminaPiuElementi(){
		// Aggiunta di elementi a r1
		r1.aggiungi("Arya=1234567");
		r1.aggiungi("Sansa=7654321");
		r1.aggiungi("Jon=7756756756");
		r1.aggiungi("Jamie=1111111");
		r1.aggiungi("Cersei=000666000");

		assertTrue(r1.numEl()==5);
		assertTrue(r1.elimina("J"));		
		assertTrue(r1.numEl()==3);

	}
	
	
	
		
}
