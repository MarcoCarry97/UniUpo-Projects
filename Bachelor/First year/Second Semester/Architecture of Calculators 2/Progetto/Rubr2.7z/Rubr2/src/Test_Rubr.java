import static org.junit.Assert.*;



import org.junit.Test;
import org.junit.Before;


public class Test_Rubr {
	Rubrica gioc,pil;
	
	@Before
	public void crea() {
		gioc = new Rubrica("Giocatori",5);
		pil = new Rubrica("Piloti",5);
	}
	
	
	@Test
	public void Testcreato() {
		assertTrue(gioc.numEl()==0);
		assertTrue(pil.numEl()==0);
	}
	
	
	@Test
	public void test_aggiungi() {
			assertEquals(gioc.add_con("Dries_Mertens = 1239456"),1);
			assertEquals(gioc.numEl(),1);
			assertEquals(pil.add_con("Andrea_Dovizioso = 9873456"),1);
			assertEquals(pil.numEl(),1);
			assertEquals(gioc.add_con("Edin_Dzeko = 5439456"),1);
			assertEquals(gioc.numEl(),2);
			assertEquals(pil.add_con("Marc_Marquez = 9074426"),1);
			assertEquals(pil.numEl(),2);
			assertEquals(gioc.add_con("Ciro_Immobile = 1139258"),1);
			assertEquals(gioc.numEl(),3);
			assertEquals(pil.add_con("Maverik_Vinales = 7073456"),1);
			assertEquals(pil.numEl(),3);
			assertEquals(gioc.add_con("Gonzalo_Higuain = 6739056"),1);
			assertEquals(gioc.numEl(),4);
			assertEquals(pil.add_con("Maverik_Vinales = 7073456"),0);
			assertEquals(pil.numEl(),3);
			assertEquals(pil.add_con("Andrea_Iannone = 9375556"),1);
			assertEquals(pil.numEl(),4);
			assertEquals(gioc.add_con("Ciril_Thereau = 8739256"),1);
			assertEquals(gioc.numEl(),5);
			assertEquals(pil.add_con("Daniel_Pedrosa = 9113496"),1);
			assertEquals(pil.numEl(),5);
			assertEquals(gioc.add_con("Federico_Chiesa = 61739756"),-1);
			assertEquals(gioc.numEl(),5);
			assertEquals(pil.add_con("Jorge_Lorenzo = 9115596"),-1);
			assertEquals(pil.numEl(),5);
			
	}
	
	@Test
	public void TestStampa() {
		add_element();
		String st;
		st = gioc.Arr_str();
		System.out.println(st);
		String st1;
		st1 = pil.Arr_str();
		System.out.print(st1);
	}
	
	@Test
	public void TestRicerca() {
		add_element();
		assertEquals(gioc.cerca_str("Cir").size(),2);
		assertEquals(gioc.cerca_str("Ed").size(),1);
		assertEquals(gioc.cerca_str("St").size(),0);
		assertEquals(pil.cerca_str("Te").size(),0);
		assertEquals(pil.cerca_str("D").size(),1);
		assertEquals(pil.cerca_str("Andr").size(),2);
	}
	
	@Test
	public void TestElimina() {
		add_element();
		assertTrue(gioc.elimina("Cir"));
		assertTrue(gioc.elimina("Ed"));
		assertEquals(gioc.numEl(),2);
		assertFalse(pil.elimina("Te"));
		assertTrue(pil.elimina("D"));
		assertEquals(pil.numEl(),4);
	}
	
	public void add_element(){
		gioc.add_con("Dries_Mertens = 1239456");
		gioc.add_con("Edin_Dzeko = 5439456");
		gioc.add_con("Ciro_Immobile = 1139258");
		gioc.add_con("Gonzalo_Higuain = 6739056");
		gioc.add_con("Ciril_Thereau = 8739256");
		pil.add_con("Marc_Marquez = 9074426");
		pil.add_con("Andrea_Dovizioso = 9873456");
		pil.add_con("Maverik_Vinales = 7073456");
		pil.add_con("Andrea_Iannone = 9375556");
		pil.add_con("Daniel_Pedrosa = 9113496");
	}
	
}


